const gulp = require('gulp');
// const uglify = require('gulp-uglify');
const postcss = require('gulp-postcss');
const autoprefixer = require('autoprefixer');
const csslint = require('gulp-csslint');
const concatCss = require('gulp-concat-css');
const cleanCss = require('gulp-clean-css');
const rename = require('gulp-rename');
// CSS POST PROCESS
exports.css = (cb) =>{
    // concatenation
    // uglify
    // post css/autoprefixer
    let config_browsers = {
        browsers:[
            '>1% in MD',
            'last 4 versions',
            'Firefox ESR',
            'not ie < 10', //will applicate only to ie 10 versions
        ]
    };


    return gulp
            .src('./src/css/*.css')                         //reading from source
            .pipe(csslint())
            .pipe(csslint.formatter())                      //coding style
            .pipe(postcss([autoprefixer(config_browsers)])) //postcss(prefixation)
            .pipe(concatCss('style.css'))
            .pipe(cleanCss())
            .pipe(rename('style.min.css'))
            .pipe(gulp.dest('./dist/css'))                  // putting file in map
            ; 
}










// DEFAULT TASK
// exports.default = (cb) =>{
//     console.log("Starting default task!");
//     cb();
// }